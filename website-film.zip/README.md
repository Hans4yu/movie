# Build & Deploy Movie App

## Technologies used

- React
- Firebase
- Chakra UI
- TMDB API
- Redux
- Tailwind
- Tailwind Css
- Redux JS

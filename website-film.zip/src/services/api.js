import axiosInstance from "./axiosInstance.js";

export const imagePath = "https://image.tmdb.org/t/p/w500";
export const imagePathOriginal = "https://image.tmdb.org/t/p/original";

// TRENDING
export const fetchTrending = async (timeWindow = "day") => {
  const { data } = await axiosInstance.get(`/trending/all/${timeWindow}`);
  return data?.results;
};

// MOVIES & SERIES - Details
export const fetchDetails = async (type, id) => {
  const { data } = await axiosInstance.get(`/${type}/${id}`);
  return data;
};

// MOVIES & SERIES - Credits
export const fetchCredits = async (type, id) => {
  const { data } = await axiosInstance.get(`/${type}/${id}/credits`);
  return {
    cast: data?.cast.map(({ id, name, profile_path }) => ({
      id,
      name,
      profile_path,
    })),
  };
};

// MOVIES & SERIES - Videos
export const fetchVideos = async (type, id) => {
  const { data } = await axiosInstance.get(`/${type}/${id}/videos`);
  return data;
};

// DISCOVER
export const fetchMovies = async (page, sortBy) => {
  const { data } = await axiosInstance.get(`/discover/movie`, {
    params: { page, sort_by: sortBy },
  });
  return data;
};

export const fetchTvSeries = async (page, sortBy) => {
  const { data } = await axiosInstance.get(`/discover/tv`, {
    params: { page, sort_by: sortBy },
  });
  return data;
};

// SEARCH
export const searchData = async (query, page) => {
  const { data } = await axiosInstance.get(`/search/multi`, {
    params: { query, page },
  });
  return data;
};

// GENRES
export const fetchGenres = async (page, genreId, sortBy = "") => {
  const { data } = await axiosInstance.get(`/discover/movie`, {
    params: { page, with_genres: genreId, sort_by: sortBy },
  });
  return data;
};

export const fetchGenreList = async () => {
  const { data } = await axiosInstance.get(`/genre/movie/list`, {
    params: { language: "en" },
  });
  return data?.genres || [];
};

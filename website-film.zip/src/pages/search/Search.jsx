import { useEffect, useState, useCallback } from "react";
import {
  Container,
  Flex,
  Grid,
  Heading,
  Input,
  Spinner,
  VStack,
  Text,
  Button,
} from "@chakra-ui/react";
import { debounce } from "lodash";
import { searchData } from "../../services/api";
import CardComponent from "../../components/CardComponent";
import PaginationComponent from "../../components/PaginationComponent";
import { useFirestore } from "../../services/firestore";
import { useAuth } from "../../context/useAuth";

const Search = () => {
  const [searchValue, setSearchValue] = useState("");
  const [activePage, setActivePage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [data, setData] = useState([]);
  const [searchHistory, setSearchHistory] = useState([]);

  const { addSearchHistory, getSearchHistory, clearSearchHistory } =
    useFirestore();
  const { user } = useAuth(); // Get the current logged-in user

  // Fetch search results
  const fetchResults = useCallback(async (value, page = 1) => {
    if (!value) return;

    setIsLoading(true);
    try {
      const res = await searchData(value, page);
      setData(res?.results || []);
      setActivePage(res?.page || 1);
      setTotalPages(res?.total_pages || 1);
    } catch (err) {
      console.error("Error fetching search results:", err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Debounce input changes to reduce API calls
  const debouncedFetchResults = useCallback(
    debounce((value, page) => fetchResults(value, page), 300),
    [fetchResults]
  );

  // Fetch search results when searchValue or activePage changes
  useEffect(() => {
    debouncedFetchResults(searchValue, activePage);
  }, [searchValue, activePage, debouncedFetchResults]);

  // Fetch search history on mount
  useEffect(() => {
    const fetchHistory = async () => {
      if (user) {
        const history = await getSearchHistory(user.uid);
        setSearchHistory(history);
      }
    };
    fetchHistory();
  }, [user, getSearchHistory]);

  const handleInputChange = (e) => {
    const value = e.target.value;
    setSearchValue(value);
    setActivePage(1); // Reset to the first page on new search
  };

  const handleClearHistory = async () => {
    if (user) {
      await clearSearchHistory(user.uid);
      setSearchHistory([]); // Clear local state
    }
  };

  const handleHistoryClick = (query) => {
    setSearchValue(query); // Trigger search for selected history item
    setActivePage(1);
  };

  return (
    <Container maxW={"container.xl"}>
      {/* Search Heading */}
      <Flex alignItems={"baseline"} gap={"4"} my={"10"}>
        <Heading as="h2" fontSize={"md"} textTransform={"uppercase"}>
          Search
        </Heading>
      </Flex>

      {/* Search Input */}
      <Input
        placeholder="Search movies, tv shows..."
        _placeholder={{ color: "gray.100" }}
        value={searchValue}
        onChange={handleInputChange}
        mb="4"
      />

      {/* Search History */}
      {user && searchHistory.length > 0 && (
        <VStack align="start" spacing="3" mb="6">
          <Heading as="h3" fontSize="sm">
            Recent Searches
          </Heading>
          {searchHistory.map((entry) => (
            <Text
              key={entry.id}
              fontSize="md"
              cursor="pointer"
              onClick={() => handleHistoryClick(entry.query)}
              _hover={{ textDecoration: "underline" }}
            >
              {entry.query}
            </Text>
          ))}
          <Button size="sm" colorScheme="red" onClick={handleClearHistory}>
            Clear History
          </Button>
        </VStack>
      )}

      {/* Search Results */}
      {isLoading && (
        <Flex justifyContent={"center"} mt="10">
          <Spinner size={"xl"} color="red" />
        </Flex>
      )}

      {data?.length === 0 && !isLoading && searchValue && (
        <Heading textAlign={"center"} as="h3" fontSize={"sm"} mt="10">
          No results found for "{searchValue}"
        </Heading>
      )}

      <Grid
        templateColumns={{
          base: "1fr",
          sm: "repeat(2, 1fr)",
          md: "repeat(4, 1fr)",
          lg: "repeat(5, 1fr)",
        }}
        gap={"4"}
        mt="6"
      >
        {data?.length > 0 &&
          !isLoading &&
          data.map((item) => (
            <CardComponent key={item?.id} item={item} type={item?.media_type} />
          ))}
      </Grid>

      {/* Pagination */}
      {data?.length > 0 && !isLoading && (
        <PaginationComponent
          activePage={activePage}
          totalPages={totalPages}
          setActivePage={setActivePage}
        />
      )}
    </Container>
  );
};

export default Search;

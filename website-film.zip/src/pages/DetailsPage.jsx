import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import {
  Badge,
  Box,
  Button,
  CircularProgress,
  CircularProgressLabel,
  Container,
  Flex,
  Heading,
  Image,
  Spinner,
  Text,
  useToast,
} from "@chakra-ui/react";
import {
  fetchCredits,
  fetchDetails,
  fetchVideos,
  imagePath,
  imagePathOriginal,
} from "../services/api";
import {
  CalendarIcon,
  CheckCircleIcon,
  SmallAddIcon,
  TimeIcon,
} from "@chakra-ui/icons";
import {
  minutesToHours,
  ratingToPercentage,
  resolveRatingColor,
} from "../utils/helpers";
import VideoComponent from "../components/VideoComponent";
import { useAuth } from "../context/useAuth";
import { useFirestore } from "../services/firestore";

const DetailsPage = () => {
  const { type, id } = useParams();

  const { user } = useAuth();
  const { addToWatchlist, checkIfInWatchlist, removeFromWatchlist } =
    useFirestore();
  const toast = useToast();

  const [details, setDetails] = useState({});
  const [cast, setCast] = useState([]);
  const [video, setVideo] = useState(null);
  const [videos, setVideos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isInWatchlist, setIsInWatchlist] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [detailsData, creditsData, videosData] = await Promise.all([
          fetchDetails(type, id),
          fetchCredits(type, id),
          fetchVideos(type, id),
        ]);

        setDetails(detailsData);
        setCast(creditsData?.cast?.slice(0, 10));

        const video = videosData?.results?.find(
          (video) => video?.type === "Trailer"
        );
        setVideo(video);

        const otherVideos = videosData?.results
          ?.filter((video) => video?.type !== "Trailer")
          ?.slice(0, 10);
        setVideos(otherVideos);
      } catch (error) {
        console.error("Error fetching details:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [type, id]);

  const handleSaveToWatchlist = async () => {
    if (!user) {
      toast({
        title: "Login to add to watchlist",
        status: "error",
        isClosable: true,
      });
      return;
    }

    const data = {
      id: details?.id,
      title: details?.title || details?.name,
      type: type,
      poster_path: details?.poster_path,
      release_date: details?.release_date || details?.first_air_date,
      vote_average: details?.vote_average,
      overview: details?.overview,
    };

    const dataId = details?.id?.toString();
    await addToWatchlist(user?.uid, dataId, data);
    setIsInWatchlist(await checkIfInWatchlist(user?.uid, dataId));
  };

  useEffect(() => {
    if (user) {
      checkIfInWatchlist(user?.uid, id).then((data) => setIsInWatchlist(data));
    } else {
      setIsInWatchlist(false);
    }
  }, [id, user, checkIfInWatchlist]);

  const handleRemoveFromWatchlist = async () => {
    await removeFromWatchlist(user?.uid, id);
    setIsInWatchlist(await checkIfInWatchlist(user?.uid, id));
  };

  if (loading) {
    return (
      <Flex justify={"center"} align={"center"} h="100vh">
        <Spinner size={"xl"} color="red" />
      </Flex>
    );
  }

  const title = details?.title || details?.name;
  const releaseDate =
    type === "tv" ? details?.first_air_date : details?.release_date;

  return (
    <Box>
      <Box
        background={`linear-gradient(rgba(0,0,0,.88), rgba(0,0,0,.88)), url(${imagePathOriginal}/${details?.backdrop_path})`}
        backgroundSize="cover"
        backgroundPosition="center"
        py="2"
        display="flex"
        alignItems="center"
      >
        <Container maxW="container.xl">
          <Flex
            alignItems="center"
            gap="10"
            direction={{ base: "column", md: "row" }}
          >
            <Image
              src={`${imagePath}/${details?.poster_path}`}
              borderRadius="sm"
              height="450px"
              alt={`${title} poster`}
            />
            <Box>
              <Heading fontSize="3xl">
                {title}{" "}
                <Text as="span" color="gray.400" fontWeight="normal">
                  {new Date(releaseDate).getFullYear()}
                </Text>
              </Heading>
              <Flex alignItems="center" gap="4" mt="1" mb="5">
                <Flex alignItems="center">
                  <CalendarIcon mr="2" color="gray.400" />
                  <Text fontSize="sm">
                    {new Date(releaseDate).toLocaleDateString("en-US")}
                  </Text>
                </Flex>
                {type === "movie" && (
                  <Flex alignItems="center">
                    <TimeIcon mr="2" color="gray.400" />
                    <Text fontSize="sm">
                      {minutesToHours(details?.runtime)}
                    </Text>
                  </Flex>
                )}
              </Flex>
              <CircularProgress
                value={ratingToPercentage(details?.vote_average)}
                size="70px"
                color={resolveRatingColor(details?.vote_average)}
              >
                <CircularProgressLabel fontSize="lg">
                  {ratingToPercentage(details?.vote_average)}%
                </CircularProgressLabel>
              </CircularProgress>
              <Button
                leftIcon={
                  isInWatchlist ? <CheckCircleIcon /> : <SmallAddIcon />
                }
                colorScheme={isInWatchlist ? "green" : "gray"}
                variant="outline"
                onClick={
                  isInWatchlist
                    ? handleRemoveFromWatchlist
                    : handleSaveToWatchlist
                }
              >
                {isInWatchlist ? "In Watchlist" : "Add to Watchlist"}
              </Button>
              <Text fontStyle="italic" color="gray.400">
                {details?.tagline}
              </Text>
              <Heading fontSize="xl">Overview</Heading>
              <Text>{details?.overview}</Text>
              <Flex mt="6" gap="2">
                {details?.genres?.map((genre) => (
                  <Badge key={genre.id}>{genre.name}</Badge>
                ))}
              </Flex>
            </Box>
          </Flex>
        </Container>
      </Box>
      <Container maxW="container.xl">
        <Heading as="h2" textTransform="uppercase" fontSize="md">
          Cast
        </Heading>
        <Flex gap="4">
          {cast.map((actor) => (
            <Image
              key={actor.id}
              src={`${imagePath}/${actor.profile_path}`}
              alt={actor.name}
            />
          ))}
        </Flex>
      </Container>
    </Box>
  );
};

export default DetailsPage;

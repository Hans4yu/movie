import React, { lazy, Suspense } from "react";

const Layout = lazy(() => import("./components/Layout"));
const HomePage = lazy(() => import("./pages/Home"));

const App = () => (
  <Suspense fallback={<div>Loading...</div>}>
    <Layout>
      <HomePage />
    </Layout>
  </Suspense>
);

export default App;

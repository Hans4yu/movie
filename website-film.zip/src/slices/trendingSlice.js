import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axiosInstance from "../services/axiosInstance.js";

// Thunk to fetch trending data
export const fetchTrendingData = createAsyncThunk(
  "trending/fetchTrendingData",
  async (timeWindow = "day") => {
    const { data } = await axiosInstance.get(`/trending/all/${timeWindow}`);
    return data.results;
  }
);

// Slice to manage trending data state
const trendingSlice = createSlice({
  name: "trending",
  initialState: {
    data: [],
    loading: false,
    error: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchTrendingData.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchTrendingData.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(fetchTrendingData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      });
  },
});

export default trendingSlice.reducer;

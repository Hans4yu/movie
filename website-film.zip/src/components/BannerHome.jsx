import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { FaAngleRight, FaAngleLeft } from "react-icons/fa";

const BannerHome = () => {
  const [currentImage, setCurrentImage] = useState(0);
  const [bannerData, setBannerData] = useState([]);

  useEffect(() => {
    const fetchBannerData = async () => {
      try {
        const apiKey = import.meta.env.VITE_API_KEY;
        const response = await fetch(
          `https://api.themoviedb.org/3/trending/all/day?api_key=${apiKey}`
        );
        const data = await response.json();
        setBannerData(data.results || []);
      } catch (error) {
        console.error("Error fetching banner data:", error);
      }
    };
    fetchBannerData();
  }, []);

  const handleNext = () => {
    if (currentImage < bannerData.length - 1) {
      setCurrentImage((prev) => prev + 1);
    }
  };

  const handlePrevious = () => {
    if (currentImage > 0) {
      setCurrentImage((prev) => prev - 1);
    }
  };

  useEffect(() => {
    const interval = setInterval(() => {
      if (currentImage < bannerData.length - 1) {
        handleNext();
      } else {
        setCurrentImage(0);
      }
    }, 5000);

    return () => clearInterval(interval);
  }, [currentImage, bannerData]);

  return (
    <section className="w-full h-screen relative overflow-hidden">
      <div className="flex min-h-full max-h-full overflow-hidden">
        {bannerData.map((data, index) => (
          <div
            key={data.id + "bannerHome" + index}
            className="min-w-full min-h-full overflow-hidden relative group transition-transform duration-700"
            style={{
              transform: `translateX(-${currentImage * 100}%)`,
            }}
          >
            <div className="w-full h-full">
              <img
                src={`https://image.tmdb.org/t/p/original${data.backdrop_path}`}
                className="h-full w-full object-cover"
                alt={data.title || data.name}
              />
            </div>
            <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-black/30 via-black/50 to-black"></div>
            <div className="absolute bottom-10 left-5 md:left-10 text-white max-w-lg space-y-4">
              <h1 className="text-2xl md:text-4xl font-bold drop-shadow-lg">
                {data.title || data.name}
              </h1>
              <p className="text-sm md:text-md line-clamp-3">{data.overview}</p>
              <div className="flex items-center gap-4">
                <p>Rating: {data.vote_average.toFixed(1)}+</p>
                <span>|</span>
                <p>Views: {data.popularity.toFixed(0)}</p>
              </div>
              <Link to={`/${data.media_type}/${data.id}`}>
  <button className="mt-4 bg-red-600 px-4 py-2 rounded-lg text-white hover:bg-red-800 transition-all">
    Play Now
  </button>
</Link>

            </div>
            <div className="absolute top-0 w-full h-full hidden items-center justify-between px-4 group-hover:flex">
              <button
                onClick={handlePrevious}
                className="bg-white p-2 rounded-full text-xl z-10 text-black hover:bg-gray-300 transition"
              >
                <FaAngleLeft />
              </button>
              <button
                onClick={handleNext}
                className="bg-white p-2 rounded-full text-xl z-10 text-black hover:bg-gray-300 transition"
              >
                <FaAngleRight />
              </button>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default BannerHome;

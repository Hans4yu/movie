module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx,ts,tsx}",
    "./public/**/*.{html,js}",
  ],
  darkMode: "class",
  theme: {
    extend: {},
  },
  plugins: [],
};
